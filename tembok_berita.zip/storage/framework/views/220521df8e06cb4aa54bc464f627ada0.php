<?php $__env->startSection('content'); ?>
<main>
    <!-- About Us Start -->
    <div class="about-area">
        <div class="container">

            <!-- Main Content -->
            <div class="row">
                <!-- About Content -->
                <div class="col-lg-8">
                    <div class="about-right mb-90 mt-50">
                        <div class="about-img">
                            <img src="<?php echo e($about->image); ?>" alt="About Us" class="img-fluid rounded shadow-sm">
                        </div>
                        <div class="section-title mb-30 pt-30">
                            <h3 class="text-primary"><?php echo e($about->title); ?></h3>
                        </div>
                        <div class="about-prea">
                            <?php echo $about->description; ?>

                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="col-lg-4">
                    <!-- Follow Us Section -->
                    <div class="section-title mb-40">
                        <h3>Follow Us</h3>
                    </div>
                    <div class="single-follow mb-45">
                        <div class="single-box">
                            <?php $__currentLoopData = ['fb' => 'Facebook', 'tw' => 'Twitter', 'ins' => 'Instagram', 'yo' => 'YouTube']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="follow-us d-flex align-items-center mb-3">
                                    <div class="follow-social mr-3">
                                        <a href="#"><img src="<?php echo e(asset("home/img/news/icon-{$key}.png")); ?>" alt="<?php echo e($value); ?>" class="img-fluid"></a>
                                    </div>
                                    <div class="follow-count">
                                        <span>8,045</span>
                                        <p><?php echo e($value); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <!-- New Poster Section -->
                    <div class="news-poster d-none d-lg-block">
                        <img src="<?php echo e(asset('home/img/news/news_card.jpg')); ?>" alt="New Poster" class="img-fluid rounded shadow-sm">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About Us End -->
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .about-area {
        background: #f9f9f9;
        padding: 60px 0;
    }
    .trending-title {
        background: #ff4b5c;
        color: white;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 20px;
    }
    .about-img img {
        transition: transform 0.3s;
    }
    .about-img img:hover {
        transform: scale(1.05);
    }
    .follow-us {
        transition: background-color 0.3s;
    }
    .follow-us:hover {
        background-color: #f1f1f1;
    }
    .follow-social img {
        width: 40px;
        height: 40px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $('#js-news').ticker();
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\_KULIAH_IRHAM_K\_SEMESTER 2\Pemrograman Web\ProjectTembokBerita\TembokBerita\resources\views/home/about.blade.php ENDPATH**/ ?>