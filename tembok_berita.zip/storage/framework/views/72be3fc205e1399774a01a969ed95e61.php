<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">List Postingan</h4>

                    <!-- Filter Buttons -->
                    <div class="mb-3">
                        <a href="<?php echo e(route('breaking-news.index', ['filter' => 'all'])); ?>" class="btn btn-info <?php echo e($filter == 'all' ? 'active' : ''); ?>">Semua</a>
                        <a href="<?php echo e(route('breaking-news.index', ['filter' => 'in_breaking_news'])); ?>" class="btn btn-info <?php echo e($filter == 'in_breaking_news' ? 'active' : ''); ?>">Tampil Trending</a>
                        <a href="<?php echo e(route('breaking-news.index', ['filter' => 'not_in_breaking_news'])); ?>" class="btn btn-info <?php echo e($filter == 'not_in_breaking_news' ? 'active' : ''); ?>">Belum tampil Trending</a>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Judul</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index + 1); ?></td>
                                    <td><?php echo e($post->title); ?></td>
                                    <td>
                                        <?php if(\App\Models\BreakingNews::where('post_id', $post->id)->exists()): ?>
                                            <form action="<?php echo e(route('breaking-news.destroy', $post->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Batal</button>
                                        <?php else: ?>
                                            <form action="<?php echo e(route('breaking-news.store')); ?>" method="POST" id="form-<?php echo e($post->id); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                                <button type="button" class="btn btn-primary" onclick="showSwal('<?php echo e($post->id); ?>')">Pilih</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center mt-4">
                        <p class="mb-0">Menampilkan <?php echo e($posts->firstItem()); ?> - <?php echo e($posts->lastItem()); ?> dari <?php echo e($posts->total()); ?> postingan</p>
                    </div>
                    <div class="d-flex justify-content-between mt-4">
                        <?php if($posts->previousPageUrl()): ?>
                        <a href="<?php echo e($posts->previousPageUrl()); ?>" class="btn btn-secondary">Previous</a>
                        <?php else: ?>
                        <button class="btn btn-secondary" disabled>Previous</button>
                        <?php endif; ?>

                        <?php if($posts->nextPageUrl()): ?>
                        <a href="<?php echo e($posts->nextPageUrl()); ?>" class="btn btn-secondary">Next</a>
                        <?php else: ?>
                        <button class="btn btn-secondary" disabled>Next</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function showSwal(id) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Postingan akan tampil di Trending",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, saya yakin!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('form-' + id).submit();
            }
        })
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\_KULIAH_IRHAM_K\_SEMESTER 2\Pemrograman Web\ProjectTembokBerita\TembokBerita\resources\views/app/breaking-news/index.blade.php ENDPATH**/ ?>