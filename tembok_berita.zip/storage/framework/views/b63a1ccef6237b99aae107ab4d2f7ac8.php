<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Buat Video Baru</h4>
                    <p>Anda dapat menggunakan link video dari YouTube. Silakan ikuti langkah-langkah berikut:</p>
                    <ol>
                        <li>Salin URL video dari YouTube.</li>
                        <li>Buka <a href="https://www.classynemesis.com/projects/ytembed/" target="_blank">https://www.classynemesis.com/projects/ytembed/</a>.</li>
                        <li>Tempelkan URL video yang disalin ke dalam kotak input di halaman tersebut.</li>
                        <li>Klik tombol "Get Embed Code".</li>
                        <li>Pastikan ada dua URL yang dihasilkan. URL pertama adalah untuk menampilkan video dalam mode tampilan yang lebih besar, sedangkan URL kedua adalah untuk menampilkan video dalam mode tampilan yang lebih kecil. Anda dapat memilih salah satu dari keduanya.</li>
                        <li>Pastikan juga ada ID video yang dihasilkan. ID video adalah bagian yang muncul setelah tanda "v=" dalam URL video.</li>
                        <li>Gunakan URL dan ID video yang dihasilkan untuk mengisi bidang "URL Video" di formulir di bawah ini.</li>
                    </ol>
                    <form action="<?php echo e(route('videos.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mt-4">
                            <label for="title">Judul Video</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" name="title" placeholder="Masukkan Judul Video" required>
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="url">Url Video</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="url" name="url" placeholder="https://www.youtube.com/embed/..." required>
                            <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary mr-2">Submit</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">List Video</h4>
                    <div class="table-responsive">
                        <p>Mohon pastikan URL video yang dimasukkan sudah benar dan video dapat dimuat dengan baik. Jika tidak dapat menampilkan video dengan benar, coba gunakan URL video lain atau periksa kembali URL yang diberikan.</p>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Video</th>
                                    <th>Judul</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index + 1); ?></td>
                                    <td>
                                        <iframe width="150" height="100" src="<?php echo e($video->url); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                    </td>
                                    <td><?php echo e($video->title); ?></td>
                                    <td>
                                        <button class="btn btn-danger" onclick="confirmDelete('<?php echo e($video->id); ?>')">Hapus</button>
                                        <form id="delete-form-<?php echo e($video->id); ?>" action="<?php echo e(route('videos.destroy', $video->id)); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center mt-4">
                        <p class="mb-0">Menampilkan <?php echo e($videos->firstItem()); ?> - <?php echo e($videos->lastItem()); ?> dari <?php echo e($videos->total()); ?> video</p>
                    </div>
                    <div class="d-flex justify-content-between mt-4">
                        <?php if($videos->previousPageUrl()): ?>
                        <a href="<?php echo e($videos->previousPageUrl()); ?>" class="btn btn-secondary">Previous</a>
                        <?php else: ?>
                        <button class="btn btn-secondary" disabled>Previous</button>
                        <?php endif; ?>

                        <?php if($videos->nextPageUrl()): ?>
                        <a href="<?php echo e($videos->nextPageUrl()); ?>" class="btn btn-secondary">Next</a>
                        <?php else: ?>
                        <button class="btn btn-secondary" disabled>Next</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>

function confirmDelete(id) {
    Swal.fire({
        title: 'Yakin hapus video?',
        text: "Video yang dihapus tidak dapat dikembalikan!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('delete-form-' + id).submit();
        }
    });
}
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\_KULIAH_IRHAM_K\_SEMESTER 2\Pemrograman Web\ProjectTembokBerita\TembokBerita\resources\views/app/video/index.blade.php ENDPATH**/ ?>