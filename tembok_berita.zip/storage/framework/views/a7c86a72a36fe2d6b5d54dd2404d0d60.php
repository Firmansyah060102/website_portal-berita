<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">List Komentar</h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Komentar</a></li>
                  <li class="breadcrumb-item active" aria-current="page">List Komentar</li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">List Komentar</h4>
                    <div class="table-responsive">
                      <table class="table table-striped">
                        <thead>
                          <tr>
                            <th>Post</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Komentar</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><a href="<?php echo e(route('posts.show', $comment->post->slug)); ?>" target="_blank"><?php echo e($comment->post->title); ?></a></td>
                            <td><?php echo e($comment->name); ?></td>
                            <td><?php echo e($comment->email); ?></td>
                            <td><?php echo e($comment->content); ?></td>
                            <td>
                                <a href="<?php echo e(route('posts.show', $comment->post->slug)); ?>" class="btn btn-primary" target="_blank">Lihat</a>
                                <button type="button" class="btn btn-danger" onclick="confirmDelete('<?php echo e($comment->id); ?>')">Hapus</button>
                                <form id="delete-form-<?php echo e($comment->id); ?>" action="<?php echo e(route('comments.destroy', $comment->id)); ?>" method="POST" class="d-none">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('DELETE'); ?>
                                </form>

                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>

                    <div class="text-center mt-4">
                        <p class="mb-0">Menampilkan <?php echo e($comments->firstItem()); ?> - <?php echo e($comments->lastItem()); ?> dari <?php echo e($comments->total()); ?> komentar</p>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <?php if($comments->previousPageUrl()): ?>
                        <a href="<?php echo e($comments->previousPageUrl()); ?>" class="btn btn-secondary">Previous</a>
                        <?php else: ?>
                        <button class="btn btn-secondary" disabled>Previous</button>
                        <?php endif; ?>

                        <?php if($comments->nextPageUrl()): ?>
                        <a href="<?php echo e($comments->nextPageUrl()); ?>" class="btn btn-secondary">Next</a>
                        <?php else: ?>
                        <button class="btn btn-secondary" disabled>Next</button>
                        <?php endif; ?>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>

<script>
function confirmDelete(id) {
    Swal.fire({
    title: 'Yakin hapus komentar?',
    text: "Komentar yang dihapus tidak dapat kembali!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Hapus',
    cancelButtonText: 'Batal'
    }).then((result) => {
    if (result.isConfirmed) {
        document.getElementById('delete-form-' + id).submit();
    }
    })
}
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\_KULIAH_IRHAM_K\_SEMESTER 2\Pemrograman Web\ProjectTembokBerita\TembokBerita\resources\views/app/comments/index.blade.php ENDPATH**/ ?>