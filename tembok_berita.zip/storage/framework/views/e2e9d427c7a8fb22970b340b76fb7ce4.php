<!DOCTYPE html>
<!-- Coding By CodingNepal - www.codingnepalweb.com -->
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Glassmorphism Login Form | CodingNepal</title>
  <link rel="stylesheet" href="<?php echo e(asset('app/css/login.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
  <div class="wrapper">
    <form action="<?php echo e(route('login.submit')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <h2>Sistem Informasi Tembok Berita</h2>
    <div class="input-field">
        <input type="email" name="email" required>
        <label>Masukkan Email</label>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: red; font-size: 12px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="input-field">
        <input type="password" name="password" required>
        <label>Masukkan Password</label>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: red; font-size: 12px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="forget">
        <label for="remember">
            <input type="checkbox" id="remember" name="remember_me">
            <p>Ingat Saya</p>
        </label>
        <a href="#">Lupa Kata Sandi?</a>
    </div>
    <button type="submit">Masuk</button>
    <div style="text-align: center; color: #fff; margin-top: 20px;">
        <p style="font-size: 12px;">ATAU</p>
    </div>
    <div class="google-login" style="margin-top: 20px;">
        <a href="<?php echo e(route('login.google')); ?>" style="display: inline-block; padding: 10px 20px; background: #dd4b39; color: #fff; border-radius: 2px; font-weight: bold;">
            <i class="fab fa-google"></i> Masuk Dengan Google
        </a>
    </div>
    <div class="register">
        <p>Belum Punya Akun? <a href="#">Mendaftar</a></p>
    </div>
</form>

  </div>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Gagal',
                text: "<?php echo e(session('error')); ?>"
            });
        </script>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: "<?php echo e(session('success')); ?>"
            });
        </script>
    <?php endif; ?>

</body>
</html>
<?php /**PATH C:\Users\User\Documents\_KULIAH_IRHAM_K\_SEMESTER 2\Pemrograman Web\ProjectTembokBerita\TembokBerita\resources\views/app/auth/login.blade.php ENDPATH**/ ?>