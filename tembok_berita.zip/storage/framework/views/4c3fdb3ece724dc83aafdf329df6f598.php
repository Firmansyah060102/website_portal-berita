<?php $__env->startSection('content'); ?>
<main>
    <div class="about-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <!-- Post Details -->
                    <div class="about-right mb-90 mt-50">
                        <div class="card mb-3 shadow-sm">
                            <img class="card-img-top" src="<?php echo e($post->image); ?>" alt="Post Image" style="height: 300px; object-fit: cover; border-radius: 10px 10px 0 0;">
                            <div class="card-body">
                                <h4 class="card-title"><?php echo e($post->title); ?></h4>
                                <div class="d-flex align-items-center mb-2 small">
                                    <i class="fas fa-user mr-2"></i>
                                    <p class="card-text mb-0"><span class="font-weight-bold">Author:</span> <?php echo e($post->user->name); ?></p>
                                </div>
                                <div class="d-flex align-items-center mb-2 small">
                                    <i class="fas fa-calendar-alt mr-2"></i>
                                    <p class="card-text mb-0"><span class="font-weight-bold">Created:</span> <?php echo e($post->created_at->format('M d, Y')); ?></p>
                                </div>
                                <?php if($post->published_at): ?>
                                    <div class="d-flex align-items-center mb-2 small">
                                        <i class="fas fa-clock mr-2"></i>
                                        <p class="card-text mb-0"><span class="font-weight-bold">Published:</span> <?php echo e($post->published_at->diffForHumans()); ?></p>
                                    </div>
                                <?php endif; ?>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="fas fa-solid fa-list mr-2"></i>
                                    <p class="card-text mb-0"><span class="font-weight-bold">Category:</span> <?php echo e($post->category->name); ?></p>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="fas fa-eye mr-2"></i>
                                    <p class="card-text mb-0"><span class="font-weight-bold">Views:</span> <?php echo e($post->views); ?></p>
                                </div>
                                <p class="card-text mt-3"><?php echo $post->body; ?></p>
                            </div>
                        </div>
                        <div class="social-share pt-30">
                            <div class="section-title">
                                <h3 class="mr-20">Share:</h3>
                                <ul class="d-flex list-unstyled">
                                    <li class="mr-3"><a href="#"><img src="<?php echo e(asset('home/img/news/icon-ins.png')); ?>" alt="Instagram"></a></li>
                                    <li class="mr-3"><a href="#"><img src="<?php echo e(asset('home/img/news/icon-fb.png')); ?>" alt="Facebook"></a></li>
                                    <li class="mr-3"><a href="#"><img src="<?php echo e(asset('home/img/news/icon-tw.png')); ?>" alt="Twitter"></a></li>
                                    <li class="mr-3"><a href="#"><img src="<?php echo e(asset('home/img/news/icon-yo.png')); ?>" alt="YouTube"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Comments Section -->
                    <div class="comments-section mb-50">
                        <h4 class="mb-4">Comments</h4>
                        <?php if($post->comments->isEmpty()): ?>
                            <p>Belum ada komentar</p>
                        <?php else: ?>
                            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="comment mb-3 p-3 bg-light border">
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="fas fa-user mr-2"></i>
                                        <p class="mb-0 font-weight-bold"><?php echo e($comment->name); ?></p>
                                    </div>
                                    <p class="mb-0" style="white-space: pre-wrap; word-wrap: break-word;"><?php echo e($comment->content); ?></p>
                                    <small class="text-muted"><?php echo e($comment->created_at->diffForHumans()); ?></small>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>

                    <!-- Comment Form -->
                    <div class="row">
                        <div class="col-lg-12">
                            <?php if(auth()->guard()->check()): ?>
                                <form class="form-contact contact_form mb-80" action="<?php echo e(route('comments.store')); ?>" method="post" id="commentForm">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="post_slug" value="<?php echo e($post->slug); ?>">

                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <textarea class="form-control w-100 <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="content" id="content" cols="30" rows="9" placeholder="Enter Comment"></textarea>
                                                <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback" style="display: block;"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <input class="form-control" name="name" id="name" type="text" value="<?php echo e(auth()->user()->name); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <input class="form-control" name="email" id="email" type="email" value="<?php echo e(auth()->user()->email); ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group mt-3">
                                        <button type="submit" class="button button-contactForm boxed-btn">Submit</button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <div class="d-flex align-items-center justify-content-center mb-5">
                                    <button type="button" class="btn btn-primary text-white rounded-pill px-4 py-2" data-toggle="modal" data-target="#loginModal">
                                        <i class="fas fa-sign-in-alt mr-2"></i>
                                        Login untuk Berdiskusi
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="col-lg-4">
                    <!-- Follow Us Section -->
                    <div class="section-title mb-40">
                        <h3>Follow Us</h3>
                    </div>
                    <div class="single-follow mb-45">
                        <div class="single-box">
                            <?php $__currentLoopData = ['fb' => 'Facebook', 'tw' => 'Twitter', 'ins' => 'Instagram', 'yo' => 'YouTube']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="follow-us d-flex align-items-center mb-3">
                                    <div class="follow-social mr-3">
                                        <a href="#"><img src="<?php echo e(asset("home/img/news/icon-{$key}.png")); ?>" alt="<?php echo e($value); ?>"></a>
                                    </div>
                                    <div class="follow-count">
                                        <span>8,045</span>
                                        <p><?php echo e($value); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <!-- Advertisement -->
                    <div class="news-poster d-none d-lg-block">
                        <img src="<?php echo e(asset('home/img/news/news_card.jpg')); ?>" alt="Advertisement">
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Login Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body text-center">
                <img src="<?php echo e(asset('home/img/logo/logo-header.svg')); ?>" alt="Login Icon" class="img-fluid mb-3 mx-auto d-block" style="max-width: 100px;">
                <h5 class="mb-3">Login untuk Berdiskusi</h5>
                <form action="<?php echo e(route('login.submit')); ?>" method="post" id="login-form">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="post_slug" id="post_slug" value="<?php echo e($post->slug); ?>">

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary text-white rounded-pill px-4 py-3">Login</button>
                </form>
                <hr>
                <a href="<?php echo e(route('login.google.slug', ['post_slug' => $post->slug])); ?>" class="btn btn-primary text-white rounded-pill px-4 py-3">
                    <i class="fab fa-google mr-2"></i>
                    Login dengan Google
                </a>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function () {
            // Initialize Bootstrap modal
            $('#loginModal').modal({
                show: false
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\_KULIAH_IRHAM_K\_SEMESTER 2\Pemrograman Web\ProjectTembokBerita\TembokBerita\resources\views/home/post-detail.blade.php ENDPATH**/ ?>