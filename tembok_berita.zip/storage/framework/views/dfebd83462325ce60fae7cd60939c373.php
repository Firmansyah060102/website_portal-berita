<!doctype html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Tembok Berita</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="manifest" href="site.webmanifest">
        <link rel="shortcut icon" href="<?php echo e(asset('home/img/logo/logo-favicon-tb.svg')); ?>" />


		<!-- CSS here -->
            <link rel="stylesheet" href="<?php echo e(asset('home/css/bootstrap.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('home/css/owl.carousel.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('home/css/ticker-style.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('home/css/flaticon.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('home/css/slicknav.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('home/css/animate.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('home/css/magnific-popup.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('home/css/fontawesome-all.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('home/css/themify-icons.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('home/css/slick.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('home/css/nice-select.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('home/css/style.css')); ?>">

        <!-- icon FA CDN -->

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">


   </head>

   <body>

    <!-- Preloader Start -->
    <!-- <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="home/img/logo/logo-tb.svg" style="width: 150px;" alt="">
                </div>
            </div>
        </div>
    </div> -->
    <!-- Preloader Start -->

    <?php echo $__env->make('component.navbar-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('component.footer-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- JS here -->

    <!-- All JS Custom Plugins Link Here here -->
    <script src="<?php echo e(asset('home/js/vendor/modernizr-3.5.0.min.js')); ?>"></script>
    <!-- Jquery, Popper, Bootstrap -->
    <script src="<?php echo e(asset('home/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/bootstrap.min.js')); ?>"></script>
    <!-- Jquery Mobile Menu -->
    <script src="<?php echo e(asset('home/js/jquery.slicknav.min.js')); ?>"></script>

    <!-- Jquery Slick , Owl-Carousel Plugins -->
    <script src="<?php echo e(asset('home/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/slick.min.js')); ?>"></script>
    <!-- Date Picker -->
    <script src="<?php echo e(asset('home/js/gijgo.min.js')); ?>"></script>
    <!-- One Page, Animated-HeadLin -->
    <script src="<?php echo e(asset('home/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/animated.headline.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/jquery.magnific-popup.js')); ?>"></script>

    <!-- Breaking New Pluging -->
    <script src="<?php echo e(asset('home/js/jquery.ticker.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/site.js')); ?>"></script>

    <!-- Scrollup, nice-select, sticky -->
    <script src="<?php echo e(asset('home/js/jquery.scrollUp.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/jquery.sticky.js')); ?>"></script>

    <!-- contact js -->
    <script src="<?php echo e(asset('home/js/contact.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/jquery.form.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/mail-script.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/jquery.ajaxchimp.min.js')); ?>"></script>

    <!-- Jquery Plugins, main Jquery -->
    <script src="<?php echo e(asset('home/js/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('home/js/main.js')); ?>"></script>

     <!-- Sweet Alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if(session('success')): ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: "<?php echo e(session('success')); ?>"
            });
        </script>
    <?php endif; ?>

    </body>
</html>
<?php /**PATH C:\Users\User\Documents\_KULIAH_IRHAM_K\_SEMESTER 2\Pemrograman Web\ProjectTembokBerita\TembokBerita\resources\views/layouts/home.blade.php ENDPATH**/ ?>