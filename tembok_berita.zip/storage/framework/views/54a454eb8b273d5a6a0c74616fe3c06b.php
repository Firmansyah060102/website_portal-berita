<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Buat Kategori Baru</h4>
                    <form action="<?php echo e(route('categories.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mt-4">
                            <label for="name">Nama Kategori</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" placeholder="Masukkan Nama Kategori" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="postImage">Gambar</label>
                            <div class="input-group col-xs-12">
                                <input type="file" class="form-control file-upload-info" id="postImage" placeholder="Upload Image" name="image">
                            </div>
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red; font-size: 12px;"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary mr-2">Submit</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">List Kategori</h4>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Gambar</th>
                                    <th>Nama</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index + 1); ?></td>
                                    <td><img src="<?php echo e($category->image); ?>" alt="<?php echo e($category->name); ?>" style="object-fit: contain; height: 50px;"></td>
                                    <td><?php echo e($category->name); ?></td>
                                    <td>
                                        <a class="btn btn-warning" href="<?php echo e(route('categories.edit', $category->slug)); ?>">Edit</a>
                                        <button class="btn btn-danger" onclick="confirmDelete('<?php echo e($category->slug); ?>')">Hapus</button>
                                        <form id="delete-form-<?php echo e($category->slug); ?>" action="<?php echo e(route('categories.destroy', $category->slug)); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center mt-4">
                        <p class="mb-0">Menampilkan <?php echo e($categories->firstItem()); ?> - <?php echo e($categories->lastItem()); ?> dari <?php echo e($categories->total()); ?> kategori</p>
                    </div>
                    <div class="d-flex justify-content-between mt-4">
                        <?php if($categories->previousPageUrl()): ?>
                        <a href="<?php echo e($categories->previousPageUrl()); ?>" class="btn btn-secondary">Previous</a>
                        <?php else: ?>
                        <button class="btn btn-secondary" disabled>Previous</button>
                        <?php endif; ?>

                        <?php if($categories->nextPageUrl()): ?>
                        <a href="<?php echo e($categories->nextPageUrl()); ?>" class="btn btn-secondary">Next</a>
                        <?php else: ?>
                        <button class="btn btn-secondary" disabled>Next</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>

function confirmDelete(slug) {
    Swal.fire({
        title: 'Yakin hapus kategori?',
        text: "Postingan yang tertaut dengan kategori akan terhapus!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('delete-form-' + slug).submit();
        }
    });
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\_KULIAH_IRHAM_K\_SEMESTER 2\Pemrograman Web\ProjectTembokBerita\TembokBerita\resources\views/app/category/index.blade.php ENDPATH**/ ?>