<footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © tim gacor 2024</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"> Salam sejahtera dari kami Angkatan 2023</span>
            </div>

            <div>
              <span class="text-muted d-block text-center text-sm-left d-sm-inline-block"> Pengembang: <a href="https://irhamkaramann.my.id/" target="_blank">Tim Gacor Tembok Berita</a></span>
            </div>
          </footer>
<?php /**PATH C:\Users\User\Documents\_KULIAH_IRHAM_K\_SEMESTER 2\Pemrograman Web\ProjectTembokBerita\TembokBerita\resources\views/component/footer-app.blade.php ENDPATH**/ ?>